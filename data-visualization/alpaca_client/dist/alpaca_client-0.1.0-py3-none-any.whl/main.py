import os
import websocket
import websockets
import _thread
import time
import json
import asyncio
import logging
import ssl
import psycopg2
import datetime

import dotenv
dotenv.load_dotenv("../secrets/alpaca.env")

from functools import wraps

print(os.getenv('DBNAME'))


def connection_wrapper(func):

    logging.basicConfig(level=logging.DEBUG)
    async def _impl(*args,**kwargs):

        while True:
            try:
                websocket_uri = 'wss://stream.data.alpaca.markets/v1beta1/crypto'
                print(websocket_uri)
                async with aiohttp.ClientSession() as session:
                    async with session.ws_connect(websocket_uri) as ws:

                        # Initial handshake
                        rec_msg = await ws.receive()
                        print(rec_msg)
                        if rec_msg.type==aiohttp.WSMsgType.TEXT:
                            rec_msg = json.loads(rec_msg.data)[0]
                            expected_msg = {"T":"success","msg":"connected"}
                            if rec_msg != expected_msg:
                                raise Exception(f'Server initial msg doesnt match expected:\n{rec_msg}!={expected_msg}')
                        else:
                            raise Exception(f'Initial server message type not expected: {rec_msg.type}')
                        logging.debug('Server connection successful')

                        # Authentication
                        await crypto_auth(ws)
                        
                        # Launch Function
                        await func(ws=ws)

            except Exception as e:
                logging.error(f'Alpaca connection failure: {e}')
    
    return _impl


async def crypto_publisher(ws,trades=[],quotes=[],bars=[]):

    listener_message = json.dumps({
        'action':'subscribe',
        'trades':trades,
        'quotes':quotes,
        'bars':bars
    })

    await ws.send_str(listener_message)

    async for msg in ws:
        if msg.type==aiohttp.WSMsgType.TEXT:
            
            data = json.loads(msg.data)
            for entry in data:
                if entry['T']=='t':
                    trade_recs.appendleft([
                        int(entry['i']),
                        entry['t'],
                        entry['S'],
                        entry['x'],
                        entry['p'],
                        entry['s'],
                        entry['tks'],
                    ])

            logging.debug(data)

        elif msg.type==aiohttp.WSMsgType.ERROR:
            logging.error(msg.data)



def on_message(ws, msg):
    msg = json.loads(msg.decode())
    if msg['stream']=='authorization':
        print

    print(msg)


def on_error(ws, error):
    print(error)


def on_close(ws, close_status_code, close_msg):
    print("### closed ###")

async def auth(ws):
    alpaca_id = os.getenv('ALPACA_API_ID')
    alpaca_secret = os.getenv('ALPACA_API_KEY')
    
    auth_message = json.dumps({
        'action':'authenticate',
        'data':{'key_id':alpaca_id,'secret_key':alpaca_secret}
    })

    await ws.send(auth_message)
    while True:
        msg = await ws.recv()
        msg = json.loads(msg)#.decode())
        ws.logger.debug(msg)

        if 'stream' not in msg:
            continue

        if msg['stream'] == 'authorization':
            auth_successful = msg['data'].get('status','') == 'authorized'
            ws.logger.debug(f'authorization succedded: {auth_successful}')
            return auth_successful
        elif msg['stream'] == 'listening':
            auth_successful = msg['data'].get('error','') == 'your connection is already authenticated'
            ws.logger.debug('authorization succeeded: already connected')
            return auth_successful

async def crypto_auth(ws):
    alpaca_id = os.getenv('ALPACA_API_ID')
    alpaca_secret = os.getenv('ALPACA_API_KEY')
    
    auth_message = json.dumps({
        'action':'auth',
        'key':alpaca_id,
        'secret':alpaca_secret,
    })

    await ws.send_str(auth_message)

    async for msg in ws:
        if msg.type == aiohttp.WSMsgType.TEXT:
            msg = json.loads(msg.data)[0]
            expected_msg = {'T': 'success', 'msg': 'authenticated'}
            if msg == expected_msg:
                break
            else:
                raise Exception(f'Unexpected auth response: {msg}')
        else:
            raise Exception(f'Auth Error: {msg.data}')

    logging.debug('Authentication successful')

async def crypto_listener(ws,trades=[],quotes=[],bars=[]):
    listener_message = json.dumps({
        'action':'subscribe',
        'trades':trades,
        'quotes':quotes,
        'bars':bars
    })

    await ws.send_str(listener_message)


    async for msg in ws:
        if msg.type==aiohttp.WSMsgType.TEXT:
            
            data = json.loads(msg.data)



            logging.debug(data)


        elif msg.type==aiohttp.WSMsgType.ERROR:
            logging.error(msg.data)



async def register_feeds(ws,target_streams):
    
    listen_message = json.dumps({
        "action": "listen",
        "data": {
            "streams": target_streams
        }
    })

    await ws.send(listen_message)



async def start_equity_ws():

    logger = logging.getLogger('websockets')
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    connection_params = {
        'uri': 'wss://data.alpaca.markets/stream', #'wss://paper-api.alpaca.markets/stream',
        'logger': logger,

    }

    target_streams = ['T.SPY','Q.SPY','AM.SPY']

    print('starting_ws')
    async with websockets.connect(**connection_params) as ws:
        try:

            # Authorize user on startup
            auth_result = await auth(ws)
            if not auth_result:
                raise Exception('Auth error')

            # Listen to target streams
            await register_feeds(ws,target_streams)

            ws.logger.debug('now listening')

            while True:
                greeting = await ws.recv()
                ws.logger.debug(greeting)

        
        except websockets.ConnectionClosed:
            print('exception')

async def start_crypto_ws():

    logger = logging.getLogger('websockets')
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler())

    headers = {
        'connection': 'upgrade',
        'upgrade': 'websocket',
    }#'Authorization': 'Basic YWRtaW46YWRtaW4='}


    connection_params = {
        'uri': 'wss://stream.data.alpaca.markets/v1beta1/crypto',
        'subprotocols': ['ISYSUB'],
        'extra_headers':headers,
        'origin': '*',
        #'logger': logger,
        #'ssl': ssl_context,
        #'origin': "*"
    }

    target_streams = ['T.SPY','Q.SPY','AM.SPY']

    print('starting_ws')
    async with websockets.connect(**connection_params) as ws:
        try:
            print(ws)

            #pong_waiter = await ws.ping()

            #await crypto_auth(ws)

            #await ws.send('aaaa')

            res = await ws.recv()
            print("Received '%s'" % res)
            
            """

            # Authorize user on startup
            auth_result = await auth(ws)
            if not auth_result:
                raise Exception('Auth error')

            # Listen to target streams
            await register_feeds(ws,target_streams)

            ws.logger.debug('now listening')

            while True:
                greeting = await ws.recv()
                ws.logger.debug(greeting)
            """

        
        except websockets.ConnectionClosed:
            print('exception')



from collections import deque
import aiohttp
import asyncio

trade_recs = deque([])


class CryptoClient():

    


    def reset_database(self):

        CONNECTION = f"postgres://{os.getenv('DBUSER')}:{os.getenv('DBPASS')}@192.168.1.13:5432/{os.getenv('DBNAME')}"
        
        print(CONNECTION)
        with psycopg2.connect(CONNECTION) as conn:
            cursor = conn.cursor()
            cursor.execute("ROLLBACK")

            try:
                cursor.execute("DROP TABLE trades")
            except:
                pass
            try:
                create_table = (
                    """
                    CREATE TABLE trades (
                        id BIGINT,
                        ts TIMESTAMP,
                        instrument VARCHAR(9),
                        exchange VARCHAR(6),
                        price DOUBLE PRECISION,
                        trade_size DOUBLE PRECISION,
                        taker_side CHAR,
                        PRIMARY KEY (id,ts));
                    """
                )
                cursor.execute(create_table);
                cursor.execute("SELECT create_hypertable('trades', 'ts');")
                
            except:
                raise Exception('Failed to create trades database table.')


    async def crypto_listener(self,ws,trades=[],quotes=[],bars=[]):
        listener_message = json.dumps({
            'action':'subscribe',
            'trades':trades,
            'quotes':quotes,
            'bars':bars
        })

        await ws.send_str(listener_message)

        async for msg in ws:
            if msg.type==aiohttp.WSMsgType.TEXT:
                
                data = json.loads(msg.data)
                for entry in data:
                    if entry['T']=='t':
                        self.trade_recs.appendleft([
                            int(entry['i']),
                            entry['t'],
                            entry['S'],
                            entry['x'],
                            entry['p'],
                            entry['s'],
                            entry['tks'],
                        ])


                logging.debug(data)


            elif msg.type==aiohttp.WSMsgType.ERROR:
                logging.error(msg.data)




    @connection_wrapper
    async def bitcoin_publisher(ws):
        trades = ['BTCUSD']
        quotes = []
        bars = []
        await crypto_publisher(ws,trades,quotes,bars)




    async def alpaca_crypto_processor(self):
        logging.basicConfig(level=logging.DEBUG)

        while True:
            try:
                websocket_uri = 'wss://stream.data.alpaca.markets/v1beta1/crypto'
                print(websocket_uri)
                async with aiohttp.ClientSession() as session:
                    async with session.ws_connect(websocket_uri) as ws:

                        # Initial handshake
                        rec_msg = await ws.receive()
                        print(rec_msg)
                        if rec_msg.type==aiohttp.WSMsgType.TEXT:
                            rec_msg = json.loads(rec_msg.data)[0]
                            expected_msg = {"T":"success","msg":"connected"}
                            if rec_msg != expected_msg:
                                raise Exception(f'Server initial msg doesnt match expected:\n{rec_msg}!={expected_msg}')
                        else:
                            raise Exception(f'Initial server message type not expected: {rec_msg.type}')
                        
                        logging.debug('Server connection successful')

                        # Authentication
                        await crypto_auth(ws)


                        # Configure listener
                        trades = ['BTCUSD']
                        quotes = []#['BTCUSD']
                        bars = []#['BTCUSD']
                        print('bb')
                        await self.crypto_listener(ws,trades,quotes,bars)

            except Exception as e:
                logging.error(f'Alpaca connection failure: {e}')

    
    async def timer(self):

        while True:
            try:
                CONNECTION = f"postgres://{os.getenv('DBUSER')}:{os.getenv('DBPASS')}@192.168.1.13:5432/{os.getenv('DBNAME')}"
                with psycopg2.connect(CONNECTION) as conn:
                    cursor = conn.cursor()

                    while True:
                        if trade_recs:
                            cr = trade_recs.pop()
                            logging.debug(cr)
                            ts = datetime.datetime.strptime(cr[1][:min(len(cr[1])-1,26)],'%Y-%m-%dT%H:%M:%S.%f')
                            ts = datetime.datetime.now(datetime.timezone.utc)
                            cursor.execute(f"INSERT INTO trades (id,ts,instrument,exchange,price,trade_size,taker_side) VALUES('{cr[0]}','{ts}','{cr[2]}','{cr[3]}',{cr[4]},{cr[5]},'{cr[6]}');")
                            #result = cursor.rowcount
                            #print('FFFFF',result)
                            conn.commit()
                        else:
                            await asyncio.sleep(0.4)
            except Exception as e:
                logging.error(f'TimescaleDB connection error: {e}')
                await asyncio.sleep(1)


async def start2():

    client = CryptoClient()
    await asyncio.gather(
        #client.alpaca_crypto_processor(),
        client.bitcoin_publisher(),
        client.timer()
    )

def reset_database():
    CryptoClient().reset_database()

def start():
    #CryptoClient().reset_database()
    asyncio.run(start2())


if __name__ == "__main__":
    start()
